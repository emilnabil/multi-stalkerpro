from skin import loadSkin
from Components.Language import language
from Tools.Directories import resolveFilename, SCOPE_PLUGINS, fileExists
from gettext import gettext, dgettext, bindtextdomain
try:
    from Plugins.Extensions.IPaudioPro.eIPaudioPro import __init__
    IPAUDIOPRO_INSTALLED = True
except ImportError:
    IPAUDIOPRO_INSTALLED = False

__version__ = 1.2

IS_ADULT = [
    'porn',
    'erotic',
    'adult',
    'xxx',
    '\+18',
    'sex',
    'blue movie'
]

PluginLanguageDomain = "MultiStalkerPro"
PluginLanguagePath = f"Extensions/{PluginLanguageDomain}/locale"

def loadPluginSkin():
    skin = resolveFilename(SCOPE_PLUGINS, "Extensions/MultiStalkerPro/assets/skins/skin.xml")
    print("[MultiStalkerPro] load skin", skin)
    if fileExists(skin):
        loadSkin(skin)

def localeInit():
    bindtextdomain(PluginLanguageDomain, resolveFilename(SCOPE_PLUGINS, PluginLanguagePath))

def _(txt):
    t = dgettext(PluginLanguageDomain, txt)
    if t == txt:
        t = gettext(txt)
    return t

localeInit()
language.addCallback(localeInit)
